Copy docs/design-reference/daekwang-mobile-app-approved-reference.jpeg into the project root:
daekwangtech_homepage_v3_function_pass/docs/design-reference/daekwang-mobile-app-approved-reference.jpeg

Do not import this file into production code. Use it only as implementation reference.
