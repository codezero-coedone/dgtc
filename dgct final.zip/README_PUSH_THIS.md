# DGTC CT-0~CT-10 Final Authority Package

This package replaces the active deployed source folder:
`daekwangtech_homepage_v3_function_pass/`

## What changed
- CT-0 active/live source marker lock added.
- CT-1 company-introduction policy re-locked.
- CT-2 bottom clipping/legacy panel risk removed by final DOM shell.
- CT-3 CTA width/style compacted.
- CT-4 detail modal changed to angular industrial card style.
- CT-5 nav/card/photo/CTA/detail click rules normalized.
- CT-6 4D Proof Loop finalized as 7 clickable DOM steps.
- CT-7 product/facility/quality evidence cards reinforced.
- CT-8 mobile safe layout and safe sheet locked.
- CT-9 verify script strengthened.
- CT-10 build/verify QA passed locally.

## Local verify
```powershell
cd daekwangtech_homepage_v3_function_pass
npm install
npm run build
npm run verify
node --check src/app.js
```

## Push/deploy
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\PUSH_ACTIVE_FOLDER_REPLACE_DGTC.ps1
```

Check after deploy:
https://dgtc.ejdzm90.workers.dev/?v=ct0-10-final#/home
