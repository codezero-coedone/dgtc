import http from 'http';
import fs from 'fs';
import path from 'path';
const root=process.cwd();
const port=4173;
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.jpg':'image/jpeg','.png':'image/png'};
http.createServer((req,res)=>{
  let url=req.url.split('?')[0];
  if(url==='/'||url==='') url='/index.html';
  let p=path.join(root,url);
  if(!p.startsWith(root)){res.writeHead(403);return res.end('Forbidden')}
  fs.readFile(p,(e,d)=>{
    if(e){res.writeHead(404);return res.end('Not found')}
    res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});
    res.end(d)
  })
}).listen(port,()=>console.log(`DAEKWANG company-only final dev server: http://localhost:${port}`));
